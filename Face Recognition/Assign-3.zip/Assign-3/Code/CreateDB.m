function T = CreateDatabase(TrainingPath)

files = dir(TrainingPath);
capacity = 0;

for i = 1:size(files,1)
    if not(strcmp(files(i).name,'.')|strcmp(files(i).name,'..')|strcmp(files(i).name,'Thumbs.db'))
        capacity = capacity + 1; 
    end
end

T = [];
for i = 1 : capacity
 
    str = int2str(i);
    str = strcat('\',str,'.jpg');
    str = strcat(TrainingPath,str);
    
    image = imread(str);
    image = rgb2gray(image);
    
    [irow icol] = size(image);
   
    swap = reshape(image',irow*icol,1);   
    T = [T swap];           
end