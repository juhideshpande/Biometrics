function [n, X, Eigenfaces] = EigenfaceCore(T)

n = mean(T,2);
capacity = size(T,2);

X = [];  
for i = 1 : capacity
    swap = double(T(:,i)) - n;
    X = [X swap]; 
end

L = X'*X; 
[V D] = eig(L); 

vector = [];
for i = 1 : size(V,2) 
    if( D(i,i)>1 )
        vector = [vector V(:,i)];
    end
end

Eigenfaces = X * vector; 