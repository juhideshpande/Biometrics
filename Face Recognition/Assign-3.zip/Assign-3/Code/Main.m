clear all
clc
close all

TrainingPath = ('D:\Data\trainingset');
TestingPath = ('D:\Data\testingset');
counter = 1;

T = CreateDB(TrainingPath);
[n, X, Eigen] = EigenValue(T);
Euclidean_distance = zeros(145,145);    

test_directory = dir(fullfile(TestingPath,'*.jpg'));
imgs = numel(test_directory);

for i = 1:imgs
    imgname = fullfile(TestingPath, test_directory(i).name);
    im = imread(imgname);
    testimg = imgname;
    [Euclidean_distance] = Identification(testimg, n, X, Eigen,Euclidean_distance,counter);
    disp(Euclidean_distance);%
    counter = counter + 1;
end
    