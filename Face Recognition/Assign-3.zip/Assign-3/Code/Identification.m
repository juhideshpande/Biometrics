function [Eucledian_distance] = Recognition(testimg, m, A, Eigenfaces,Eucledian_distance, counter)

projectimg = [];
capacity = size(Eigenfaces,2);
for i = 1 : capacity
    swap = Eigenfaces'*A(:,i);
    projectimg = [projectimg swap]; 
end

imput = imread(testimg);
swap = imput(:,:,1);

[irow icol] = size(swap);
image = reshape(swap',irow*icol,1);
diff = double(image)-m; 
testimgprojection = Eigenfaces'*diff; 

for i = 1 : capacity
    a = projectimg(:,i);
    swap = ( norm( testimgprojection - a ) )^2;
    Eucledian_distance(counter , i) = swap;
end

